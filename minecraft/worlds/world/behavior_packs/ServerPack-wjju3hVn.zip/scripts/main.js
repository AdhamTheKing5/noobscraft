import { world, BlockPermutation, system } from "@minecraft/server";

import './antidupe.js';

const directions = [
  { name: "up", vec: { x: 0, y: 1, z: 0 } },
  { name: "down", vec: { x: 0, y: -1, z: 0 } },
  { name: "north", vec: { x: 0, y: 0, z: -1 } },
  { name: "south", vec: { x: 0, y: 0, z: 1 } },
  { name: "west", vec: { x: -1, y: 0, z: 0 } },
  { name: "east", vec: { x: 1, y: 0, z: 0 } },
];

const directions_2 = [
  { name: "up", vec: { x: 0, y: 1, z: 0 } },
  { name: "down", vec: { x: 0, y: -1, z: 0 } },
  { name: "north", vec: { x: 0, y: 0, z: -1 } },
  { name: "south", vec: { x: 0, y: 0, z: 1 } },
  { name: "west", vec: { x: -1, y: 0, z: 0 } },
  { name: "east", vec: { x: 1, y: 0, z: 0 } },
  { name: "north_east", vec: { x: 1, y: 0, z: -1 } },
  { name: "south_east", vec: { x: 1, y: 0, z: 1 } },
  { name: "north_west", vec: { x: -1, y: 0, z: -1 } },
  { name: "south_west", vec: { x: -1, y: 0, z: 1 } },
];

function addVec3(a, b) {
  return {
    x: a.x + b.x,
    y: a.y + b.y,
    z: a.z + b.z,
  };
}

function subtractVec3(a, b) {
  return {
    x: b.x - a.x,
    y: b.y - a.y,
    z: b.z - a.z,
  };
}

function isGrass(block) {
  if (block.typeId=="minecraft:grass_block") return true;
  return false;
}

function updateBlockStates(block) {
  if (!blockIds.includes(block.typeId)) return;

  const states = {};
  const north = block.north();
  const south = block.south();
  const west = block.west();
  const east = block.east();
  const northWest = block.north().west();
  const northEast = block.north().east();
  const southWest = block.south().west();
  const southEast = block.south().east();

  for (const { name, vec } of directions) {
    const neighborLoc = addVec3(block.location, vec);
    const neighbor = block.dimension.getBlock(neighborLoc);

    let isConnected = false;

    if (block.typeId == "gao:connected_sand" || block.typeId == "gao:connected_gravel") {
      if (name == "up" || name == "down") continue;

      isConnected = neighbor && neighbor.typeId == "minecraft:grass_block"
      states[`gao:connected_${name}`] = isConnected;

      states["gao:connected_north_west"] = isGrass(northWest) && north.typeId === block.typeId && west.typeId === block.typeId;
      states["gao:connected_north_east"] = isGrass(northEast) && north.typeId === block.typeId && east.typeId === block.typeId;
      states["gao:connected_south_west"] = isGrass(southWest) && south.typeId === block.typeId && west.typeId === block.typeId;
      states["gao:connected_south_east"] = isGrass(southEast) && south.typeId === block.typeId && east.typeId === block.typeId;
    }
    
    else if (block.typeId.includes("planks")) {
      isConnected = neighbor &&
        neighbor.typeId.includes("planks") &&
        neighbor.typeId !== block.typeId &&
        blockIds.includes(neighbor.typeId);
      states[`gao:connected_${name}`] = isConnected;
    }
    
    else if (block.typeId.includes("bricks")) {
      const sBricks = ["gao:connected_bricks", "gao:connected_resin_bricks"];

      if (sBricks.includes(block.typeId)) {
        isConnected = neighbor &&
          sBricks.includes(neighbor.typeId) &&
          neighbor.typeId !== block.typeId &&
          blockIds.includes(neighbor.typeId);
      }

      else {
        isConnected = neighbor &&
          neighbor.typeId.includes("bricks") &&
          !sBricks.includes(neighbor.typeId) &&
          neighbor.typeId !== block.typeId &&
          blockIds.includes(neighbor.typeId);
      }

      states[`gao:connected_${name}`] = isConnected;
    }
    
    else {
      isConnected = neighbor && neighbor.typeId === block.typeId;
      states[`gao:connected_${name}`] = isConnected;
    }

    if (block.typeId.includes("pane") && name !== "up" && name !== "down") {
      const blockConnected = isBlockConnected(neighbor, block);
      states[`gao:connected_${name}_b`] = blockConnected;
    }
  }

  const newPerm = BlockPermutation.resolve(block.typeId, states);
  block.setPermutation(newPerm);
}

function updateNeighbors(pos, dimension) {
  for (const { vec } of directions_2) {
    const neighborLoc = addVec3(pos, vec);
    const neighbor = dimension.getBlock(neighborLoc);
    if (neighbor && blockIds.includes(neighbor.typeId)) {
      updateBlockStates(neighbor);
    }
  }
}

const ConnectedBlockComponent = {
  onPlace({ block }) {
    updateBlockStates(block);
    updateNeighbors(block.location, block.dimension);
  }
}

system.beforeEvents.startup.subscribe(({ blockComponentRegistry }) => {
  blockComponentRegistry.registerCustomComponent(
    "gao:connected_block",
    ConnectedBlockComponent
  );
});

world.afterEvents.playerPlaceBlock.subscribe(event => {
  const block = event.block;

  updateNeighbors(block.location, block.dimension);
});

world.afterEvents.playerBreakBlock.subscribe(event => {
  const pos = event.block.location;
  const dimension = event.block.dimension;

  updateNeighbors(pos, dimension);
});

world.afterEvents.pistonActivate.subscribe((eventData) => {
  const { block, piston, isExpanding } = eventData;
  const attachedBlocks = piston.getAttachedBlocks()[0]

  if (attachedBlocks) {

    if (isExpanding) {
      const beforeLoc = attachedBlocks.location;
      system.runTimeout(() => {

        const vec3diff = subtractVec3(block.location, attachedBlocks.location)
        const vec3sum = addVec3(attachedBlocks.location, vec3diff)
        const pushedBlock = block.dimension.getBlock(vec3sum);

        updateBlockStates(pushedBlock);
        updateNeighbors(pushedBlock.location, pushedBlock.dimension)
        updateNeighbors(beforeLoc, pushedBlock.dimension)
      }, 2);
    } else if (!isExpanding) {
      system.runTimeout(() => {
        const beforeLoc = attachedBlocks.location;
        const retractedBlock = block.dimension.getBlock(beforeLoc);

        const vec3diff = subtractVec3(beforeLoc, block.location)
        const rBlockLoc = transformVector(vec3diff);
        const vec3sum = addVec3(attachedBlocks.location, rBlockLoc)

        updateNeighbors(beforeLoc, retractedBlock.dimension);
        updateNeighbors(vec3sum, retractedBlock.dimension);
      }, 2);
    }
  }

});

function transformVector(vector) {
  const swap = (n) => {
    if (n === 1) return 2;
    if (n === 2) return 1;
    if (n === -1) return -2;
    if (n === -2) return -1;
    return n;
  };

  return {
    x: swap(vector.x),
    y: swap(vector.y),
    z: swap(vector.z)
  };
}

const blockIds = [
  "gao:connected_glass", "gao:connected_white_glass",
  "gao:connected_light_gray_glass", "gao:connected_gray_glass",
  "gao:connected_black_glass", "gao:connected_brown_glass",
  "gao:connected_red_glass", "gao:connected_orange_glass",
  "gao:connected_yellow_glass", "gao:connected_lime_glass",
  "gao:connected_green_glass", "gao:connected_cyan_glass",
  "gao:connected_light_blue_glass", "gao:connected_blue_glass",
  "gao:connected_purple_glass", "gao:connected_magenta_glass",
  "gao:connected_pink_glass", "gao:connected_tinted_glass",

  "gao:connected_diamond_block", "gao:connected_iron_block",
  "gao:connected_gold_block", "gao:connected_redstone_block",
  "gao:connected_lapis_block", "gao:connected_netherite_block",

  "gao:connected_bookshelf", "gao:connected_sea_lantern",
  "gao:connected_smooth_stone", "gao:connected_polished_andesite",
  "gao:connected_polished_granite", "gao:connected_polished_diorite",
  "gao:connected_polished_tuff", "gao:connected_polished_deepslate",
  "gao:connected_polished_blackstone", "gao:connected_quartz_block",
  "gao:connected_sandstone", "gao:connected_red_sandstone",

  "gao:connected_glass_pane", "gao:connected_white_glass_pane",
  "gao:connected_light_gray_glass_pane", "gao:connected_gray_glass_pane",
  "gao:connected_black_glass_pane", "gao:connected_brown_glass_pane",
  "gao:connected_red_glass_pane", "gao:connected_orange_glass_pane",
  "gao:connected_yellow_glass_pane", "gao:connected_lime_glass_pane",
  "gao:connected_green_glass_pane", "gao:connected_cyan_glass_pane",
  "gao:connected_light_blue_glass_pane", "gao:connected_blue_glass_pane",
  "gao:connected_purple_glass_pane", "gao:connected_magenta_glass_pane",
  "gao:connected_pink_glass_pane",

  "gao:connected_oak_planks", "gao:connected_spruce_planks",
  "gao:connected_birch_planks", "gao:connected_jungle_planks",
  "gao:connected_acacia_planks", "gao:connected_dark_oak_planks",
  "gao:connected_mangrove_planks", "gao:connected_cherry_planks",
  "gao:connected_bamboo_planks", "gao:connected_pale_oak_planks",
  "gao:connected_crimson_planks", "gao:connected_warped_planks",

  "gao:connected_stone_bricks", "gao:connected_tuff_bricks",
  "gao:connected_mossy_stone_bricks", "gao:connected_cracked_stone_bricks",
  "gao:connected_polished_blackstone_bricks", "gao:connected_cracked_polished_blackstone_bricks",
  "gao:connected_deepslate_bricks", "gao:connected_cracked_deepslate_bricks",

  "gao:connected_bricks", "gao:connected_resin_bricks",
  
  "gao:connected_sand", "gao:connected_gravel"
];



const blacklist = [
  'minecraft:dandelion',
  'minecraft:poppy',
  'minecraft:blue_orchid',
  'minecraft:allium',
  'minecraft:azure_bluet',
  'minecraft:red_tulip',
  'minecraft:orange_tulip',
  'minecraft:white_tulip',
  'minecraft:pink_tulip',
  'minecraft:oxeye_daisy',
  'minecraft:cornflower',
  'minecraft:lily_of_the_valley',
  'minecraft:wither_rose',

  'minecraft:crimson_roots',
  'minecraft:warped_roots',
  'minecraft:pink_petals',
  'minecraft:wildflowers',
  'minecraft:torchflower',
  'minecraft:cactus_flower',
  'minecraft:closed_eyeblossom',
  'minecraft:open_eyeblossom',
  'minecraft:nether_sprouts',

  'minecraft:sunflower',
  'minecraft:lilac',
  'minecraft:rose_bush',
  'minecraft:peony',
  'minecraft:pitcher_plant',

  'minecraft:short_grass',
  'minecraft:tall_grass',
  'minecraft:short_dry_grass',
  'minecraft:tall_dry_grass',
  'minecraft:fern',
  'minecraft:large_fern',

  'minecraft:glow_lichen',
  'minecraft:spore_blossom',
  'minecraft:small_dripleaf',
  'minecraft:big_dripleaf',
  'minecraft:mangrove_roots',
  'minecraft:hanging_roots',
  'minecraft:pale_hanging_moss',
  'minecraft:leaf_litter',
  'minecraft:pointed_dripstone',
  'minecraft:bamboo',
  'minecraft:kelp',
  'minecraft:lily_pad',

  'minecraft:web',
  'minecraft:amethyst_cluster',
  'minecraft:resin_clump',
  'minecraft:daylight_sensor',
  'minecraft:stonecutter',
  'minecraft:conduit',
  'minecraft:heavy_weighted_pressure_plate',
  'minecraft:seagrass',
  'minecraft:redstone_wire',
  'minecraft:redstone_repeater',
  'minecraft:redstone_comparator',
  'minecraft:ladder',
  'minecraft:lever',
  'minecraft:tripwire_hook',
  'minecraft:string',
  'minecraft:sculk_vein',
  'minecraft:brewing_stand',
  'minecraft:grindstone',
  'minecraft:enchanting_table',
  'minecraft:cauldron',
  'minecraft:decorated_pot',
  'minecraft:flower_pot',

  'minecraft:beetroot',
  'minecraft:wheat',
  'minecraft:pumpkin_stem',
  'minecraft:melon_stem',

  'minecraft:red_mushroom',
  'minecraft:brown_mushroom',
  'minecraft:lantern',
  'minecraft:soul_lantern',

  'minecraft:scaffolding',
  'minecraft:sea_pickle',
  'minecraft:string',
  'minecraft:heavy_core',
  'minecraft:lectern',
  'minecraft:hopper',
  'minecraft:chain'
];


function isBlockConnected(neighbor, block) {
  return neighbor && neighbor.typeId !== block.typeId &&
    neighbor.typeId !== "minecraft:air" && neighbor.typeId !== "minecraft:water" &&
    neighbor.typeId !== "minecraft:lava" && !neighbor.typeId.includes("slab") &&
    !neighbor.typeId.includes("carpet") && !neighbor.typeId.includes("door") &&
    !neighbor.typeId.includes("bed") && !neighbor.typeId.includes("coral") &&
    !neighbor.typeId.includes("rail") && !neighbor.typeId.includes("sapling") &&
    !neighbor.typeId.includes("sign") && !neighbor.typeId.includes("_plate") &&
    !neighbor.typeId.includes("_layer") && !neighbor.typeId.includes("candle") &&
    !neighbor.typeId.includes("torch") && !neighbor.typeId.includes("stair") &&
    !neighbor.typeId.includes("banner") && !neighbor.typeId.includes("fence") &&
    !neighbor.typeId.includes("button") && !neighbor.typeId.includes("sculk_s") &&
    !neighbor.typeId.includes("campfire") && !neighbor.typeId.includes("anvil") &&
    !neighbor.typeId.includes("chest") && !neighbor.typeId.includes("shulker_box") &&
    !neighbor.typeId.includes("frame") && !neighbor.typeId.includes("_skull") &&
    !neighbor.typeId.includes("head") && !neighbor.typeId.includes("fire") &&
    !neighbor.typeId.includes("rod") && !neighbor.typeId.includes("leaves") &&
    !neighbor.typeId.includes("crop") && !neighbor.typeId.includes("_bud") &&
    !neighbor.typeId.includes("vine") && !neighbor.typeId.includes("plant") &&
    !neighbor.typeId.includes("bush") && !neighbor.typeId.includes("chorus") &&
    !neighbor.typeId.includes("fungus") && !neighbor.typeId.includes("egg") &&
    !neighbor.typeId.includes("azalea") && !blacklist.includes(neighbor.typeId);
}